import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';

// --- THEME ---
const COLORS = {
  bg: '#F8F9FD',
  primary: '#002d69',
  cardBg: '#ffffff',
  textMain: '#1e293b',
  textSub: '#64748b',
  border: '#e2e8f0',
  inputBg: '#f1f5f9',
};

const AddStaffScreen = ({ navigation }: any) => {
  const [name, setName] = useState('');
  const [staffId, setStaffId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleCreateStaff = () => {
    if (!name || !staffId || !password) {
      Alert.alert('Missing Fields', 'Please fill in all details.');
      return;
    }

    // API Call logic would go here
    Alert.alert('Success', `Staff Member ${name} created successfully!`, [
      { text: 'OK', onPress: () => navigation.goBack() },
    ]);
  };

  // Reusable Input Component
  const InputField = ({ label, icon, value, onChangeText, placeholder, isPassword = false }: any) => (
    <View style={styles.inputGroup}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.inputContainer}>
        <View style={styles.iconBox}>
           <MaterialCommunityIcons name={icon} size={20} color={COLORS.primary} />
        </View>
        <TextInput
          style={styles.input}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#94a3b8"
          secureTextEntry={isPassword && !showPassword}
        />
        {isPassword && (
          <TouchableOpacity 
            onPress={() => setShowPassword(!showPassword)}
            style={styles.eyeIcon}
          >
             <MaterialCommunityIcons 
                name={showPassword ? "eye-off" : "eye"} 
                size={20} 
                color="#94a3b8" 
             />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />

      {/* HEADER */}
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={COLORS.primary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add New Staff</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.content}>
            
            {/* Header / Icon Section */}
            <View style={styles.heroSection}>
                <View style={styles.heroIconCircle}>
                    <MaterialCommunityIcons name="account-plus" size={40} color={COLORS.primary} />
                </View>
                <Text style={styles.heroTitle}>Staff Onboarding</Text>
                <Text style={styles.heroSubtitle}>Create credentials for new sales executives</Text>
            </View>

            {/* FORM CARD */}
            <View style={styles.formCard}>
                <InputField 
                    label="Full Name" 
                    icon="account" 
                    placeholder="e.g. Rahul Sharma"
                    value={name}
                    onChangeText={setName}
                />

                <InputField 
                    label="Sales Executive ID" 
                    icon="badge-account-horizontal" 
                    placeholder="e.g. SE-2025"
                    value={staffId}
                    onChangeText={setStaffId}
                />

                <InputField 
                    label="Password" 
                    icon="lock" 
                    placeholder="Enter secure password"
                    value={password}
                    onChangeText={setPassword}
                    isPassword={true}
                />
            </View>

            {/* ACTION BUTTON */}
            <TouchableOpacity 
                style={styles.createButton} 
                activeOpacity={0.8}
                onPress={handleCreateStaff}
            >
                <Text style={styles.btnText}>Create Staff Account</Text>
                <MaterialCommunityIcons name="arrow-right" size={20} color="#fff" />
            </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default AddStaffScreen;

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.bg },

  /* HEADER */
  headerContainer: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 15,
  },
  backButton: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: '#ffffff',
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1, shadowRadius: 4, elevation: 3,
    borderWidth: 1, borderColor: '#f1f5f9',
  },
  headerTitle: { fontSize: 18, fontWeight: '700', color: COLORS.primary },

  content: { padding: 20 },

  /* HERO SECTION */
  heroSection: { alignItems: 'center', marginBottom: 30, marginTop: 10 },
  heroIconCircle: {
      width: 80, height: 80, borderRadius: 40, backgroundColor: '#e0e7ff',
      alignItems: 'center', justifyContent: 'center', marginBottom: 15,
      borderWidth: 1, borderColor: '#c7d2fe'
  },
  heroTitle: { fontSize: 22, fontWeight: '800', color: COLORS.primary },
  heroSubtitle: { fontSize: 14, color: COLORS.textSub, marginTop: 5 },

  /* FORM STYLES */
  formCard: {
      backgroundColor: COLORS.cardBg, borderRadius: 16, padding: 20, marginBottom: 25,
      shadowColor: '#64748b', shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
  },
  inputGroup: { marginBottom: 20 },
  label: { fontSize: 13, fontWeight: '600', color: COLORS.textMain, marginBottom: 8, marginLeft: 4 },
  inputContainer: {
      flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.inputBg,
      borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, height: 50,
  },
  iconBox: { width: 50, alignItems: 'center', justifyContent: 'center' },
  input: { flex: 1, fontSize: 15, color: COLORS.textMain, height: '100%' },
  eyeIcon: { paddingHorizontal: 15, justifyContent: 'center', height: '100%' },

  /* BUTTON */
  createButton: {
      backgroundColor: COLORS.primary, borderRadius: 12, paddingVertical: 16,
      flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
      shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.3, shadowRadius: 8, elevation: 4,
  },
  btnText: { color: '#ffffff', fontSize: 16, fontWeight: '700', marginRight: 8 },
});