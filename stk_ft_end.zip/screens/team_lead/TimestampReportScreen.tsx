import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
    StatusBar,
    FlatList,
    Platform,
    Modal,
    ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import DateTimePicker from '@react-native-community/datetimepicker';

// --- THEME CONSTANTS ---
const COLORS = {
    primary: '#004aad',
    background: '#f8f9fa',
    white: '#ffffff',
    text: '#002d69',
    subText: '#666666',
    border: '#e6f0ff',
    success: '#10B981',
    greyLine: '#cbd5e1',
};

// --- DUMMY DATA FOR EXECUTIVES ---
const EXECUTIVES = [
    { id: '1', name: 'All Executives' },
    { id: '2', name: 'Rahul Sharma' },
    { id: '3', name: 'Priya Singh' },
    { id: '4', name: 'Amit Verma' },
];

// --- HELPER: Random Lead Generator for a specific Date ---
const getRandomLeadsForDate = (dateStr: string, execId: string) => {
    // If a specific executive is selected, we simulate fewer results or specific logic
    // For demo, we just randomize the count
    const count = Math.floor(Math.random() * 5); // 0 to 4 leads per day
    if (count === 0) return [];

    const sampleNames = ['Priya Interior', 'Metro Builders', 'Rajesh Kumar', 'City Heights', 'Green View', 'Bansal Retail', 'Tech Park'];

    const leads = [];
    for (let i = 0; i < count; i++) {
        leads.push({
            id: Math.random().toString(),
            name: sampleNames[Math.floor(Math.random() * sampleNames.length)],
            time: `${Math.floor(Math.random() * 12) + 1}:${Math.floor(Math.random() * 59).toString().padStart(2, '0')} ${Math.random() > 0.5 ? 'AM' : 'PM'}`,
            amount: Math.random() > 0.3 ? `₹${(Math.random() * 5).toFixed(1)}L` : '-',
        });
    }
    return leads;
};

const TimestampReportScreen = ({ navigation }: any) => {
    // --- STATE ---
    const [selectedExecutive, setSelectedExecutive] = useState(EXECUTIVES[0]);
    const [showExecModal, setShowExecModal] = useState(false);

    // Date Logic: Default to last 3 days
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());

    // Picker State
    const [showPicker, setShowPicker] = useState(false);
    const [pickerMode, setPickerMode] = useState<'start' | 'end'>('start');

    const [reportData, setReportData] = useState<any[]>([]);

    // Helper to format Date to String (DD-MM-YYYY) for Display
    const formatDateDisplay = (date: Date) => {
        return date.toLocaleDateString('en-GB').replace(/\//g, '-');
    };

    // --- CORE LOGIC: Generate Data based on Range ---
    const generateDynamicReport = () => {
        const data = [];
        const currentDate = new Date(startDate);
        const lastDate = new Date(endDate);

        // Reset times to compare dates accurately
        currentDate.setHours(0, 0, 0, 0);
        lastDate.setHours(0, 0, 0, 0);

        // Loop from Start Date to End Date
        while (currentDate <= lastDate) {
            const dateStr = formatDateDisplay(currentDate);

            // Get random leads for this specific day
            const leads = getRandomLeadsForDate(dateStr, selectedExecutive.id);

            if (leads.length > 0) {
                data.push({
                    date: dateStr,
                    leads: leads
                });
            }

            // Add 1 day
            currentDate.setDate(currentDate.getDate() + 1);
        }

        setReportData(data);
    };

    // Initial Load
    useEffect(() => {
        // Set default range (e.g., today)
        generateDynamicReport();
    }, []); // Only run once on mount


    // --- HANDLERS ---
    const openDatePicker = (mode: 'start' | 'end') => {
        setPickerMode(mode);
        setShowPicker(true);
    };

    const onDateChange = (event: any, selectedDate?: Date) => {
        setShowPicker(false);
        if (selectedDate) {
            if (pickerMode === 'start') {
                setStartDate(selectedDate);
            } else {
                setEndDate(selectedDate);
            }
        }
    };

    // --- RENDER CARD ---
    const renderCard = (item: any) => (
        <TouchableOpacity
            key={item.id}
            style={styles.card}
            activeOpacity={0.8}
            onPress={() => navigation.navigate('TimeTracking', {
                customerName: item.name, 
                leadId: item.id
            })}
        >
            <View style={styles.cardHeader}>
                <View style={styles.avatarContainer}>
                    <Icon name="account" size={16} color={COLORS.primary} />
                </View>
                <Text style={styles.clientName} numberOfLines={1}>{item.name}</Text>
            </View>

            <View style={styles.infoRow}>
                <Icon name="clock-time-four-outline" size={12} color={COLORS.subText} />
                <Text style={styles.infoText}>{item.time}</Text>
            </View>

            <View style={[styles.infoRow, { marginTop: 4 }]}>
                <Icon name="currency-inr" size={12} color={COLORS.subText} />
                <Text style={styles.infoText}>{item.amount}</Text>
            </View>

            <View style={styles.cardFooter}>
                <View style={styles.statusBadge}>
                    <Text style={styles.statusText}>Completed</Text>
                </View>
                <View style={styles.viewAction}>
                    <Text style={styles.viewText}>View</Text>
                    <Icon name="chevron-right" size={14} color={COLORS.primary} />
                </View>
            </View>
        </TouchableOpacity>
    );

    // --- RENDER DATE SECTION ---
    const renderDateSection = ({ item }: { item: any }) => (
        <View style={styles.sectionContainer}>

            {/* Separator Style Header - CENTERED */}
            <View style={styles.separatorContainer}>
                <View style={styles.separatorLine} />
                <View style={styles.dateBubble}>
                    <Text style={styles.separatorDate}>{item.date}</Text>
                </View>
                <View style={styles.separatorLine} />
            </View>

            <Text style={styles.floatingCount}>{item.leads.length} Leads</Text>

            {/* Grid Container */}
            <View style={styles.gridContainer}>
                {item.leads.map((lead: any) => renderCard(lead))}
            </View>
        </View>
    );

    return (
        <SafeAreaView style={styles.safeArea}>
            <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />

            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                    <Icon name="chevron-left" size={28} color={COLORS.primary} />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Timeline Report</Text>
                <View style={{ width: 40 }} />
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>

                {/* --- FILTERS SECTION --- */}
                <View style={styles.filterContainer}>

                    <Text style={styles.inputLabel}>Sales Executive</Text>
                    <TouchableOpacity
                        style={styles.dropdownBox}
                        onPress={() => setShowExecModal(true)}
                    >
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Icon name="account-tie" size={20} color={COLORS.primary} style={{ marginRight: 10 }} />
                            <Text style={styles.inputText}>{selectedExecutive.name}</Text>
                        </View>
                        <Icon name="chevron-down" size={24} color={COLORS.subText} />
                    </TouchableOpacity>

                    <View style={styles.dateRow}>
                        <View style={{ flex: 1, marginRight: 10 }}>
                            <Text style={styles.inputLabel}>Start Date</Text>
                            <TouchableOpacity
                                style={styles.dateBox}
                                onPress={() => openDatePicker('start')}
                            >
                                <Icon name="calendar-start" size={18} color={COLORS.subText} style={{ marginRight: 8 }} />
                                <Text style={styles.dateInputText}>{formatDateDisplay(startDate)}</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={{ flex: 1 }}>
                            <Text style={styles.inputLabel}>End Date</Text>
                            <TouchableOpacity
                                style={styles.dateBox}
                                onPress={() => openDatePicker('end')}
                            >
                                <Icon name="calendar-end" size={18} color={COLORS.subText} style={{ marginRight: 8 }} />
                                <Text style={styles.dateInputText}>{formatDateDisplay(endDate)}</Text>
                            </TouchableOpacity>
                        </View>
                    </View>

                    {/* Apply Button - NOW TRIGGERS GENERATION */}
                    <TouchableOpacity
                        style={styles.applyButton}
                        activeOpacity={0.7}
                        onPress={generateDynamicReport}
                    >
                        <Text style={styles.applyButtonText}>Apply Filters</Text>
                        <Icon name="filter-check-outline" size={18} color={COLORS.white} />
                    </TouchableOpacity>
                </View>

                {/* --- RESULTS LIST --- */}
                <View style={styles.resultsContainer}>
                    <FlatList
                        data={reportData}
                        renderItem={renderDateSection}
                        keyExtractor={(item) => item.date}
                        scrollEnabled={false}
                        ListEmptyComponent={
                            <View style={{ alignItems: 'center', marginTop: 30 }}>
                                <Text style={{ color: COLORS.subText }}>No leads found for this range.</Text>
                            </View>
                        }
                    />
                </View>

                <View style={{ height: 40 }} />
            </ScrollView>

            {/* --- DATE PICKER MODAL --- */}
            {showPicker && (
                <DateTimePicker
                    value={pickerMode === 'start' ? startDate : endDate}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={onDateChange}
                />
            )}

            {/* --- MODAL FOR EXECUTIVE --- */}
            <Modal visible={showExecModal} transparent animationType="fade">
                <TouchableOpacity
                    style={styles.modalOverlay}
                    activeOpacity={1}
                    onPress={() => setShowExecModal(false)}
                >
                    <View style={styles.modalContent}>
                        <Text style={styles.modalTitle}>Select Executive</Text>
                        {EXECUTIVES.map((exec) => (
                            <TouchableOpacity
                                key={exec.id}
                                style={styles.modalItem}
                                onPress={() => {
                                    setSelectedExecutive(exec);
                                    setShowExecModal(false);
                                }}
                            >
                                <Text style={[
                                    styles.modalItemText,
                                    selectedExecutive.id === exec.id && { color: COLORS.primary, fontWeight: '700' }
                                ]}>
                                    {exec.name}
                                </Text>
                                {selectedExecutive.id === exec.id && (
                                    <Icon name="check" size={20} color={COLORS.primary} />
                                )}
                            </TouchableOpacity>
                        ))}
                    </View>
                </TouchableOpacity>
            </Modal>

        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: COLORS.background,
        ...Platform.select({ android: { paddingTop: StatusBar.currentHeight } }),
    },

    // Header
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        paddingVertical: 15,
        backgroundColor: COLORS.white,
        borderBottomWidth: 1,
        borderBottomColor: COLORS.border,
    },
    backBtn: { width: 40 },
    headerTitle: { fontSize: 18, fontWeight: '700', color: COLORS.text },

    // Filters
    filterContainer: {
        backgroundColor: COLORS.white,
        margin: 20,
        padding: 20,
        borderRadius: 16,
        shadowColor: COLORS.primary,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
        elevation: 3,
    },
    inputLabel: {
        fontSize: 12, fontWeight: '700', color: '#94a3b8',
        marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5,
    },
    dropdownBox: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        backgroundColor: '#F3F6FC', borderWidth: 1, borderColor: COLORS.border,
        borderRadius: 10, paddingHorizontal: 15, paddingVertical: 12, marginBottom: 16,
    },
    inputText: { fontSize: 14, color: COLORS.text, fontWeight: '600' },
    dateRow: { flexDirection: 'row', marginBottom: 16 },
    dateBox: {
        flexDirection: 'row', alignItems: 'center',
        backgroundColor: '#F3F6FC', borderWidth: 1, borderColor: COLORS.border,
        borderRadius: 10, paddingHorizontal: 12, paddingVertical: 12,
    },
    dateInputText: { fontSize: 13, color: COLORS.text, fontWeight: '600' },
    applyButton: {
        backgroundColor: COLORS.primary, flexDirection: 'row',
        alignItems: 'center', justifyContent: 'center',
        paddingVertical: 14, borderRadius: 10,
    },
    applyButtonText: {
        color: COLORS.white, fontWeight: '700', fontSize: 14, marginRight: 8,
    },

    // Results
    resultsContainer: { paddingHorizontal: 20 },
    sectionContainer: { marginBottom: 25 },

    // --- CENTERED SEPARATOR STYLES ---
    separatorContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center', // Ensures content is centered
        marginBottom: 8,
        marginTop: 5,
    },
    separatorLine: {
        height: 1,
        backgroundColor: COLORS.greyLine,
        flex: 1,
    },
    dateBubble: {
        paddingHorizontal: 12,
    },
    separatorDate: {
        fontSize: 13,
        fontWeight: '700',
        color: '#64748b',
        textAlign: 'center',
    },
    floatingCount: {
        textAlign: 'right',
        fontSize: 10,
        color: '#94a3b8',
        fontWeight: '600',
        marginBottom: 10,
        marginTop: -4
    },

    // Grid & Card
    gridContainer: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    card: {
        backgroundColor: COLORS.white, width: '48%', borderRadius: 12, padding: 12, marginBottom: 12,
        borderWidth: 1, borderColor: COLORS.border,
        shadowColor: COLORS.text, shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05, shadowRadius: 4, elevation: 2,
    },
    cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
    avatarContainer: {
        width: 24, height: 24, borderRadius: 12, backgroundColor: COLORS.border,
        alignItems: 'center', justifyContent: 'center', marginRight: 8,
    },
    clientName: { fontSize: 13, fontWeight: '700', color: COLORS.text, flex: 1 },
    infoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 2 },
    infoText: { fontSize: 11, color: COLORS.subText, marginLeft: 6 },

    cardFooter: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        marginTop: 12, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#f1f5f9',
    },
    statusBadge: { backgroundColor: '#dcfce7', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 4 },
    statusText: { fontSize: 10, fontWeight: '700', color: COLORS.success },
    viewAction: { flexDirection: 'row', alignItems: 'center' },
    viewText: { fontSize: 11, fontWeight: '700', color: COLORS.primary, marginRight: 2 },

    // Modal
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    modalContent: { width: '80%', backgroundColor: COLORS.white, borderRadius: 12, padding: 20 },
    modalTitle: { fontSize: 16, fontWeight: '700', color: COLORS.text, marginBottom: 15 },
    modalItem: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
    modalItemText: { fontSize: 14, color: COLORS.subText },
});

export default TimestampReportScreen;