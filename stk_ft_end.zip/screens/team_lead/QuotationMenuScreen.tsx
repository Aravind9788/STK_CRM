import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';

// --- THEME ---
const COLORS = {
  bg: '#F8F9FD',
  primary: '#002d69',
  cardBg: '#ffffff',
  textMain: '#1e293b',
  textSub: '#64748b',
  border: '#e2e8f0',
  redAccent: '#ef4444',    // High Urgency
  orangeAccent: '#f59e0b', // Medium Urgency
  greenAccent: '#10b981',  // Low Urgency
};

// --- MOCK DATA ---
const QUOTATIONS = [
  {
    id: 'Q-1001',
    clientName: 'Priya Interiors',
    amount: '₹1,25,000',
    urgency: 'High', // Logic: High = Red, Medium = Orange
    salesPerson: 'Rahul Sharma',
    date: '27 Oct 2025',
    status: 'Pending Approval',
    items: ['False Ceiling - 1200 sqft', 'Grid Ceiling - 400 sqft'],
  },
  {
    id: 'Q-1002',
    clientName: 'Metro Builders',
    amount: '₹45,000',
    urgency: 'Medium',
    salesPerson: 'Amit Verma',
    date: '28 Oct 2025',
    status: 'Pending Approval',
    items: ['Gypsum Board - 50 pcs'],
  },
  {
    id: 'Q-1003',
    clientName: 'City Heights',
    amount: '₹8,50,000',
    urgency: 'High',
    salesPerson: 'Vikram Singh',
    date: '29 Oct 2025',
    status: 'Pending Approval',
    items: ['Full Building Contract', 'Material + Labor'],
  },
];

const QuotationMenuScreen = ({ navigation }: any) => {

  // Helper to get color based on urgency
  const getUrgencyColor = (level: string) => {
    switch (level) {
      case 'High': return COLORS.redAccent;
      case 'Medium': return COLORS.orangeAccent;
      default: return COLORS.greenAccent;
    }
  };

  const renderQuotationCard = ({ item }: any) => {
    const urgencyColor = getUrgencyColor(item.urgency);

    return (
      <TouchableOpacity
        style={styles.card}
        activeOpacity={0.9}
        onPress={() => navigation.navigate('QuotationApprovalScreen', { quotation: item })}
      >

        <View style={styles.cardContent}>
          
          {/* Top Row: Client Name & Amount */}
          <View style={styles.headerRow}>
            <View>
                <Text style={styles.clientName}>{item.clientName}</Text>
                <Text style={styles.idText}>#{item.id}</Text>
            </View>
            <View style={styles.amountBadge}>
               <Text style={styles.amountText}>{item.amount}</Text>
            </View>
          </View>

          <View style={styles.divider} />

          {/* Details Row: Sales Person & Urgency Tag */}
          <View style={styles.detailsRow}>
              
              {/* Sales Person */}
              <View style={styles.userBlock}>
                  <View style={styles.smallAvatar}>
                      <MaterialCommunityIcons name="account" size={14} color={COLORS.primary} />
                  </View>
                  <Text style={styles.userName}>{item.salesPerson}</Text>
              </View>

              {/* Urgency Badge */}
              <View style={[styles.urgencyBadge, { borderColor: urgencyColor }]}>
                  <MaterialCommunityIcons name="alert-circle-outline" size={12} color={urgencyColor} style={{ marginRight: 4 }} />
                  <Text style={[styles.urgencyText, { color: urgencyColor }]}>{item.urgency} Priority</Text>
              </View>

          </View>

        </View>
        
        {/* Right Chevron */}
        <View style={styles.chevronContainer}>
             <MaterialCommunityIcons name="chevron-right" size={24} color="#cbd5e1" />
        </View>

      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />

      {/* HEADER */}
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={COLORS.primary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Pending Quotations</Text>
        <View style={{ width: 40 }} />
      </View>

      <FlatList
        data={QUOTATIONS}
        renderItem={renderQuotationCard}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
};

export default QuotationMenuScreen;

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.bg },
  
  /* HEADER */
  headerContainer: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 15,
  },
  backButton: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: '#ffffff',
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1, shadowRadius: 4, elevation: 3,
    borderWidth: 1, borderColor: '#f1f5f9',
  },
  headerTitle: { fontSize: 18, fontWeight: '700', color: COLORS.primary },

  listContainer: { padding: 20 },

  /* CARD */
  card: {
    flexDirection: 'row', backgroundColor: COLORS.cardBg, borderRadius: 16, marginBottom: 16,
    overflow: 'hidden', shadowColor: '#64748b', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 8, elevation: 3,
  },
  accentBar: { width: 5 },
  
  cardContent: { flex: 1, padding: 16, paddingRight: 5 },
  
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  clientName: { fontSize: 16, fontWeight: '700', color: COLORS.textMain },
  idText: { fontSize: 12, color: COLORS.textSub, marginTop: 2 },
  
  amountBadge: { backgroundColor: '#f0f9ff', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  amountText: { fontSize: 14, fontWeight: '800', color: COLORS.primary },

  divider: { height: 1, backgroundColor: '#f1f5f9', marginVertical: 12 },

  detailsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  
  userBlock: { flexDirection: 'row', alignItems: 'center' },
  smallAvatar: { 
      width: 24, height: 24, borderRadius: 12, backgroundColor: '#e2e8f0', 
      alignItems: 'center', justifyContent: 'center', marginRight: 8 
  },
  userName: { fontSize: 13, fontWeight: '600', color: COLORS.textMain },

  urgencyBadge: { 
      flexDirection: 'row', alignItems: 'center', borderWidth: 1, 
      paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12, backgroundColor: '#fff' 
  },
  urgencyText: { fontSize: 10, fontWeight: '700' },

  chevronContainer: { justifyContent: 'center', paddingRight: 10 },
});