declare module 'react-native-vector-icons/MaterialCommunityIcons';
